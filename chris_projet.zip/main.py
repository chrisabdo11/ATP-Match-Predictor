import pandas as pd 
from scraper import scrape_table_1, scrape_table_2
from functions import clean_name,get_player_row,filter_by_surface
from player import Player
from predictor import MatchPredictor

url = "https://www.tennisabstract.com/reports/atp_elo_ratings.html"
df1 = scrape_table_1(url)
url_2 = "https://www.wheeloratings.com/tennis_atp_stats_last52.html"
df2 = scrape_table_2(url_2)
surface = input ("Entrez la surface de jeu : ").strip().lower().capitalize()
df2 = filter_by_surface (df2,surface)
df_total = df1.merge(df2, how = 'inner', on  = ["Player"])
name_A = input("Entrez le nom du premier joueur : ").strip()
name_A = clean_name(name_A)
name_B = input ("Entrez le nom du deuxieme joueur : ").strip()
name_B = clean_name(name_B)
playerA = get_player_row(df_total,name_A)
playerB = get_player_row(df_total,name_B)
if playerA is None:
    print("The first player is unfindable !")
    exit()
if playerB is None:
    print("The second player is unfindable !")
    exit()
player_A = Player(name_A,playerA)
player_B = Player(name_B,playerB)
predictor = MatchPredictor(df_total)
result = predictor.predict(name_A, name_B, surface)

probA, probB = result

print("\nResults:")
print(f"{name_A} : {probA:.2%}")
print(f"{name_B} : {probB:.2%}")







