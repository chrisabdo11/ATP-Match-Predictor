import numpy as np 
from player import Player
from functions import get_player_row

class MatchPredictor:
    def __init__(self, df):
        self.df = df

    def get_player(self, name):
        row = get_player_row(self.df, name)
        if row is None:
            return None
        return Player(row["Player"], row)

    def predict(self, nameA, nameB, surface):
        playerA = self.get_player(nameA)
        playerB = self.get_player(nameB)
        if playerA is None or playerB is None:
            return None
        eloA = float(playerA.get("Elo"))
        eloB = float(playerB.get("Elo"))
        probA = 1 / (1 + 10 ** ((eloB - eloA) / 400))
        probB = 1 - probA
        return probA, probB